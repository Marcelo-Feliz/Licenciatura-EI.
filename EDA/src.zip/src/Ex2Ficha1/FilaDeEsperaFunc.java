package Ex2Ficha1;

//Exercício está errado, devia ter sido implementado com arraylists, não ter criado uma queue finita, REFAZER

public class FilaDeEsperaFunc<T> implements FilaDeEspera<T>{

    int maxSize;
    int first = 0;
    int last = 0;

    private T[] fila;

    public FilaDeEsperaFunc(int maxSize){
        this.maxSize = maxSize;
    }

    public FilaDeEsperaFunc(){
        this.maxSize = 20;
        fila = (T[]) new Object[maxSize];
    }

    public int size() {
        return last;
    }

    public int maxSize(){
        return maxSize;
    }

    public int places() {
        return maxSize - last;
    }

    public void add(T algo){
        fila[last] = algo;
        last++;
    }

    public boolean isFull(){
        if (size()==maxSize){
            return true;
        }
        return false;
    }
    public boolean isEmpty(){
        if(size()==0){
            return true;
        }
        return false;
    }

    public T front(){
        return fila[first];
    }
    public T remove(){
        T returned = fila[last];
        last--;
        return returned;
    }
    public String ordena(){
        if(isEmpty()){
            return "Não há fila";
        }
        String frase = "[ ";
        for (int i = 0; i<size(); i++){
            if(i == size()-1){
                frase = frase + fila[i] + " ";
            }else {
                frase = frase + fila[i] + " ; ";
            }
        }
        frase = frase + "]";
        return frase;
    }

    public static void main(String[] args){
        FilaDeEsperaFunc fila = new FilaDeEsperaFunc();
        fila.add(2);
        fila.add("Cão");
        fila.add('h');
        fila.add(23);
        fila.add("ão");
        fila.add('r');
        fila.add(232);
        fila.add("Cã");
        fila.add('j');
        fila.add(2356);
        fila.add("Co");
        fila.add('l');
        fila.ordena();

        int i = fila.size();
        System.out.println(fila.ordena());
    }
}
