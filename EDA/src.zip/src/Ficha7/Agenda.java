package Ficha7;

public class Agenda{

    ABPtest<Contacto> agenda = new ABPtest<Contacto>();

    Contacto x;

    static class Contacto implements Comparable<Contacto>{
        String nome;
        int num;

        public Contacto(String nome){
            this.nome=nome;
            num=0;
        }
        public Contacto(String nome, int num){
            this.nome=nome;
            this.num=num;
        }
        public int compareTo(Contacto x){
            return nome.compareTo(x.nome);
        }
        public String toString(){
            return "Nome - " + nome + " cujo contacto é: " + num + "\n";
        }
    }

    public void find(String nome) {
        int valor = find(nome, agenda.getRaiz());
        if(valor == 0){
            System.out.println("O número do(a) " + nome + " é desconhecido");
        }else {
            System.out.println("O número do(a) " + nome + " é " + find(nome, agenda.getRaiz()));
        }
    }
    private Integer find(String nome, ABPtest.BNode<Contacto> n){
        if(n == null){
            return 0;
        }
        else{
            if (n.element.nome.compareTo(nome)<0) {
                return find(nome, n.right);
            }
            else if (n.element.nome.compareTo(nome)>0) {
                return find(nome, n.left);
            }
            else{
                return n.element.num;
            }
        }
    }
    public void insere(Contacto x) {
        agenda.insert(x);
    }
    public void remove(Contacto x) {
        agenda.remove(x);
    }
    public void list() {
        agenda.printEmOrdem();
    }
    public void findName(int num){
        if (agenda.getRaiz() != null) {
            findName(agenda.getRaiz(), num);
        }
    }
    private void findName(ABPtest.BNode<Contacto> n, int num) {
        if (n != null) {
            findName(n.left, num);
            if(n.element.num == num){
                System.out.println("O número "+ num + " é do(a) " + n.element.nome);
            }
            findName(n.right, num);
        }
    }

    public static void main(String[] args){
        Agenda temporary = new Agenda();
        temporary.insere(new Contacto("Pedro", 962626262));
        temporary.insere(new Contacto("Abel", 932323232));
        temporary.insere(new Contacto("João", 912121212));
        temporary.insere(new Contacto("André", 963636363));
        temporary.insere(new Contacto("Ana", 913131313));
        temporary.remove(new Contacto("Ana"));
        temporary.list();
        temporary.find("Andreia");
        temporary.findName(912121212);
    }
}
