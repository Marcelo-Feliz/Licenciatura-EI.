package Ficha2;

public class Circle extends Shape {

    public double raio;
    public double pi = 3.1415926;

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public void setRaio(){
        raio = 5;
    }

    public double area(){
        double area = pi*raio*raio;
        return area;
    }

}
