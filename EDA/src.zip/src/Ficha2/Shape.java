package Ficha2;

public abstract class Shape {
    public abstract double area();

    public int compareTo(Shape shape2){
        return Double.compare(area(), shape2.area());
    }
    public String toString(){
        return "I am a class " +this.getClass().getSimpleName() + " my area is: " +this.area();
    }
}
