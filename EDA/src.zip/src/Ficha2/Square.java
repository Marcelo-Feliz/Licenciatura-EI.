package Ficha2;

public class Square extends Shape {
    public double lado;

    public void setLado(double lado) {
        this.lado = lado;
    }

    public void setLado(){
        lado = 5;
    }

    public double area(){
        double area = lado * lado;
        return area;
    }

}
