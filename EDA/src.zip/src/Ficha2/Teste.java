package Ficha2;
import java.util.ArrayList;

public class Teste {

    public static double totalShape(ArrayList<Shape> arr1){
        double total = 0;
        for(int i =0; i<arr1.size()-1; i++){
            total = total + arr1.get(i).area();
        }
        return total;
    }


    public static void main(String[] args){
        Square re = new Square();
        re.setLado();
        //System.out.println(re.toString());
        Circle le = new Circle();
        Circle te = new Circle();
        te.setRaio(9);
        Square ye = new Square();
        ye.setLado(8);
        le.setRaio();
        ArrayList<Shape> arr1 = new ArrayList<>(100);
        arr1.add(re);
        arr1.add(le);
        arr1.add(te);
        arr1.add(ye);
        System.out.println(totalShape(arr1));

    }
}
