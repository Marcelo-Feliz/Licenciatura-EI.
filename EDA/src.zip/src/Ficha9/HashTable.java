package Ficha9;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class HashTable<T> {

    static final int tamDef = 1000000021;                  // Tamanho default (primo)
    Elemento[] array;                                  // Array onde vão ficar os elementos
    int ocupados;                                      // Número de posições ocupadas (que não estao vazias)


    ///// Classe para criar o elemento /////

    public class Elemento<T>{

        public T  elemento;
        public boolean existe;

        public Elemento( T e ) {
            this.elemento = e;
            existe = true;
        }

        public Elemento( T e, boolean i ) {
            elemento  = e;
            existe = i;
        }
    }

    ///// Construtor vazio /////

    public HashTable( ){
        alocarTabela(tamDef);
    }

    ///// Construtor para uma tabela cuja dimensão é o primeiro inteiro primo maior que tamDef /////

    public HashTable( int tamDef1 ){
        alocarTabela(tamDef1);
    }

    private static int nextPrime(int n ) {
        if( n % 2 == 0 )
            n++;

        for(; !isPrime( n ); n += 2 )
            ;

        return n;
    }

    private static boolean isPrime(int n ) {
        if( n == 2 || n == 3 ) {
            return true;
        }

        if( n == 1 || n % 2 == 0 ) {
            return false;
        }

        for( int i = 3; i*i <= n; i += 2 ) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    ///// Método que retorna o n de posições ocupadas na tabela /////

    public int ocupados(){
        return ocupados;
    }

    ///// Método que retorna o n de posições na tabela /////

    public int capacity( ) {
        return array.length;
    }

    ///// Método que retorna o fator carga /////

    public float fatorCarga(){
        return (float)ocupados/array.length;
    }

    ///// Retorna a posição em que x será inserido ou se existe a sua localização na tabela /////
    /////     Este método esta só implementado para correção de colisões de forma linear    /////

    protected int procPos(T x ) {
        int posi = x.hashCode( )%array.length;

        if( posi < 0 ) {
            posi += array.length;                    //caso o hashcode do objeto dê um valor negativo somamos-lhe o tamanho do array n vezes até ser um valor entre 0 e o tamanho do array
        }

        while( array[ posi ] != null && !array[ posi ].elemento.equals( x ) ) {     //caso x já exista na tabela nessa posição
            posi ++;
            if( posi >= array.length ) {
                posi = 0;                            //caso a posição ultrapasse o tamanho do array, volta à posição 0
            }
        }

        return posi;
    }

    ///// Método para criar uma nova tabela de dimensao n /////

    public void alocarTabela(int n){
        array = new Elemento[ nextPrime( n ) ];
    }

    ///// Método para esvaziar a tabela em uso /////

    public void tornarVazia( ) {
        ocupados = 0;
        for( int i = 0; i < array.length; i++ ){
            array[ i ] = null;
        }
    }

    ///// Procura se x existe na tabela, se estiver retorna-o se não retorna null /////

    public T procurar(T x){
        int posi = procPos(x);
        if(existe(posi)){
            return x;
        }
        return null;
    }

    private boolean existe( int currentPos ) {
        return array[ currentPos ] != null && array[ currentPos ].existe;
    }

    ///// Método que remove o elemento da tabela /////

    public void remove( T x ) {
        int posi = procPos( x );
        if( existe( posi ) ) {
            array[posi] = null;
            ocupados--;
        }
    }

    ///// Método para inserir o elemento com o valor x na sua respetiva posição na HashTable /////

    public void insere(T x ){

        int posicao = procPos( x );

        array[ posicao ] = new Elemento<>( x );
        ocupados++;

        if( fatorCarga() > 0.7 ) {                 //caso a tabela esteja ocupada a +70% faz-se rehash
            rehash();
        }
    }

    ///// Método rehash, caso o array esteja com espaço vazio limitado é necessário aumentar (neste caso duplicar) o tamanho do mesmo /////

    public void rehash( ){
        Elemento<T> [ ] arrayAntigo = array;
        int tamAntigo = array.length;

        array = new Elemento[ nextPrime( 2 * tamAntigo ) ];
        ocupados = 0;

        for( Elemento<T> posicao : arrayAntigo ) {
            if (posicao != null && posicao.existe) {
                insere(posicao.elemento);
            }
        }
    }

    ///// Método que printa todas os objetos na tabela do tipo "[elemento] -> posição na tabela " /////

    public void print(){
       for(int i = 0; i<capacity(); i++){
           if(array[i] != null){
               System.out.println("[" + array[i].elemento + "]" + " -> " + i);
           }
       }
    }

    public static void main( String [ ] args ) throws FileNotFoundException {
        HashTable<String> H = new HashTable<>( );
        String palavra;
        File file = new File("/home/shady/Desktop/dicionario");
        Scanner sc = new Scanner(new BufferedReader(new FileReader(file)));
        Scanner sc1 =  new Scanner(new BufferedReader(new FileReader(file)));
        while(sc.hasNextLine()) {
            palavra = sc.nextLine();
            H.insere(palavra);
        }
        H.print();
        System.out.println(H.capacity());
    }
}