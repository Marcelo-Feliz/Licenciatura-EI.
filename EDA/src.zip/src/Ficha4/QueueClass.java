package Ficha4;

public class QueueClass<E> implements Queue<E>{

    private E[] queue;
    int last=0;
    int size;
    int first=0;

    public QueueClass(int size){
        this.size = size;
        queue = (E[]) new Object[size];
    }

    public QueueClass(){
        this.size = 20;
        queue = (E[]) new Object[size];
    }

    public void enqueue(E o){
        if(full()){
            throw new IndexOutOfBoundsException("Queue cheia");
        }
        queue[last]=o;
        last++;
    }

    public E front(){
        if(empty()){
            throw new IndexOutOfBoundsException("Queue vazia");
        }
        return queue[first];
    }

    public E dequeue(){
        if(empty()){
            throw new IndexOutOfBoundsException("Queue vazia");
        }
        E returned = queue[first];
        first++;
        return returned;

    }

    public int size(){          //tamanho atual
        return (last-first);
    }

    public boolean empty(){
        if(last == first){
            return true;
        }
        return false;
    }

    public boolean full(){
        if (size()==size){
            return true;
        }
        return false;
    }

    public static void main(String [] args){
        QueueClass<Integer> fila = new QueueClass<Integer>(4);
        fila.enqueue(8);
        fila.enqueue(7);
        fila.enqueue(23);
        fila.enqueue(4);
        System.out.println();
        //System.out.println(fila.front());
        //fila.dequeue();
        //fila.enqueue(6);
        if(fila.full()){
            System.out.println("está cheia");
        }else if(fila.empty()){
            System.out.println("está vazia");
        }else{
            System.out.println(fila.front());
        }
    }

}
