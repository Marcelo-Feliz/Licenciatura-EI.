package Ficha4;


import java.util.EmptyStackException;
import java.util.InputMismatchException;

public class BusStopW {
    static int num1=0;
    static int timeH;
    static int timeM;
    static QueueClass<Integer>  fila = new QueueClass<>(1000);

    public static String morePeople(int arrive, int alreadyThere){
        if(timeM < 10 && timeH >= 10) {
            return "Hora "+timeH + ":0"+timeM + ", " + arrive + " pessoas chegaram, " + alreadyThere + " pessoas estão na fila.";
        }else if(timeH < 10 && timeM >= 10){
            return "Hora 0"+timeH + ":"+timeM + ", " + arrive + " pessoas chegaram, " + alreadyThere + " pessoas estão na fila.";
        }else if(timeH < 10 && timeM < 10){
            return "Hora 0"+timeH + ":0"+timeM + ", " + arrive + " pessoas chegaram, " + alreadyThere + " pessoas estão na fila.";
        }
        return "Hora "+timeH + ":"+timeM + ", " + arrive + " pessoas chegaram, " + alreadyThere + " pessoas estão na fila.";
    }
    public static String busArrive(int busCap, int alreadyThere){
        if(timeM < 10 && timeH >= 10) {
            return "Hora "+timeH + ":0"+timeM + ", " + busCap + " pessoas saíram, " + alreadyThere + " pessoas estão na fila.";
        }else if(timeH < 10 && timeM >= 10){
            return "Hora 0"+timeH + ":"+timeM + ", " + busCap + " pessoas saíram, " + alreadyThere + " pessoas estão na fila.";
        }else if(timeH < 10 && timeM < 10){
            return "Hora 0"+timeH + ":0"+timeM + ", " + busCap + " pessoas saíram, " + alreadyThere + " pessoas estão na fila.";
        }
        return "Hora "+timeH + ":"+timeM + ", " + busCap + " pessoas saíram, " + alreadyThere + " pessoas estão na fila.";
    }
    public static double tempoMedioEspera(int timeh, int timem, int num){



        return 0;
    }
    public static boolean codigo(char codigo){
        if(codigo == 'B'){
            return true;
        }else if(codigo == 'P'){
            return false;
        }else{
            throw new InputMismatchException("Código não existente!");
        }
    }
    public static void morePeople(int num){
        num1 = num1 + num;
        for (int i = 0; i<num-1; i++){
            fila.enqueue(1);
        }
    }
    public static void busArrive(int num){
        if(fila.empty()){
            throw new EmptyStackException();
        }
        for (int i = 0; i<num-1; i++){
            fila.dequeue();
        }num1 = num1 - num;
    }
    public static void codIdentification(char cod, int num, int timeh, int timem){
        if(codigo(cod)){
            busArrive(num);
            timeH = timeh;
            timeM = timem;
            System.out.println(busArrive(num, num1));
        }else{
            morePeople(num);
            timeH = timeh;
            timeM = timem;
            System.out.println(morePeople(num, num1));
        }

    }

    public static void main(String[] args){
        /*codIdentification('P',5,9,3);
        codIdentification('P', 32, 11, 4);
        codIdentification('B', 12, 14, 59);
        codIdentification('P',42,15,16);
        codIdentification('B',53,17,9);*/
    }

}
