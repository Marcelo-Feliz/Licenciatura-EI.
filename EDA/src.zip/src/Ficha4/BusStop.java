package Ficha4;

import java.lang.reflect.Array;

class Grupo{
    int h;
    int m;
    int n;
    Grupo(int h , int m, int n){
        this.h=h;
        this.m=m;
        this.n=n;
    }
}

public class BusStop{

    int num1=0;

    QueueClass<Grupo>  fila = new QueueClass<>(1000);

    public void chegaGrupo(int h, int m, int n){
        fila.enqueue(new Grupo(h,m,n));
        num1= num1 + n;
        System.out.println("Hora "+ h +":"+ m + ", " + n + " pessoas chegaram, " + num1 + " pessoas ficaram na fila.");

    }
    public void chegaAutocarro(int h, int m, int n){
        Grupo t = fila.front();
        if(n > t.n){
            fila.dequeue();
        }
        num1= num1-n;
        System.out.println("Hora "+ h +":"+ m + ", " + n + " pessoas saíram, " + num1 + " pessoas ficaram na fila.");
    }
    public double tempoMedioMin(){



        return 0;
    }

    public static void main(String[] args){
        BusStop p = new BusStop();
        p.chegaGrupo(13,23, 5);
        p.chegaGrupo(13,28, 3);
        p.chegaAutocarro(14,01,4);
    }

}
