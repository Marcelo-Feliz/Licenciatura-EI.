package Ex1Ficha1;

public class Teste {

    public static void main(String[] args){
        Fracao frac = new Fracao();
        Fracao frac2 = new Fracao(82,32);
        Fracao frac3 = new Fracao(82,31);
        frac = frac2.div(frac3);
        int res = frac2.compareTo(frac3);
        System.out.println(res);
    }
}
