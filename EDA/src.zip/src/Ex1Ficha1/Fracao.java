package Ex1Ficha1;

public class Fracao implements Comparable<Fracao>{

    int denom, numer;

    public Fracao(){
        denom = 1;
        numer = 0;
    }

    public Fracao(int int1){
        numer = int1;
        denom = 1;
    }

    public Fracao(int int1, int int2){
        numer = int1;
        denom = int2;
        reduce();

    }

    public String toString() {
        return numer +"/"+denom;
    }

    public static int mdc( int x, int y ){
        if(x == y){
            return x;
        }
        else if( y > x ){
            return mdc( x, y-x );
        }
        else if( x > y ){
            return mdc( x - y, y );
        }
        return 0;
    }
    public void reduce(){
        int k = mdc(numer, denom);
        numer = numer / k;
        denom = denom /k;
    }

    public Fracao sum(Fracao x){
        return new Fracao(numer*x.denom + x.numer*denom, denom*x.denom);
    }

    public Fracao mult(Fracao numer){            //exemplificar porq o this. só é necessario se o nome se repetir
        return new Fracao(this.numer*numer.numer, denom*numer.denom);
    }

    public Fracao div(Fracao x){
        return new Fracao(numer*x.denom, denom*x.numer);
    }

    public int compareTo(Fracao x){
        double resul = (double) this.numer / (double) this.denom;
        double resul2 = (double) x.numer / (double) x.denom;
        if(resul<resul2){
            return -1;
        }else if(resul==resul2){
            return 0;
        }else{
            return 1;
        }
    }
}