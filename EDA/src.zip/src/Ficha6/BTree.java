package Ficha6;

public class BTree <E>
{
    //variavel
    public BNode <E> raiz;

    //construtor
    public BTree (E element){
        this.raiz = new BNode<>(element);
    }

    public BTree (E element, BNode<E> esq, BNode <E> drt){
        this.raiz = new BNode<>(element, esq, drt);
    }

    //metodos
    public void emOrdem(){
        emOrdem(raiz);
        System.out.println(" ");
    }

    public void emOrdem(BNode <E> raiz){
        if(raiz != null){
            emOrdem(raiz.getLeft());
            System.out.print(" " + raiz.getElement() + " ");
            emOrdem(raiz.getRigth());
        }
    }

    public void posOrdem(){
        posOrdem(raiz);
        System.out.println(" ");
    }

    public void posOrdem(BNode <E> raiz){
        if(raiz != null){
            posOrdem(raiz.getLeft());
            posOrdem(raiz.getRigth());
            System.out.print(" " + raiz.element + " ");
        }
    }

    public void preOrdem(){
        preOrdem(raiz);
        System.out.println(" ");
    }

    public void preOrdem(BNode <E> raiz){
        if(raiz != null){
            System.out.print(" " + raiz.element + " ");
            preOrdem(raiz.getLeft());
            preOrdem(raiz.getRigth());
        }
    }

}