package Ficha6;
import java.util.StringTokenizer;

public class ArvExp{


    private static boolean operator(String s) {
        return (s.length() == 1) && s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/");
    }
    private static boolean isNum(String s) {
        try{
            float f = Float.valueOf(s).floatValue();
            return true;
        }
        catch (Exception e){
            String message = (e.getMessage());
        }
        return false;
    }

    public static float avalia(BTree<String> x) {
        return avalia(x.raiz);
    }

    public static float avalia(BNode<String> n) {
        if(isNum(n.getElement())) {
            return Float.valueOf(n.getElement()).floatValue();
        }
        else {
            return operacao(n.getElement(), avalia(n.getLeft()), avalia(n.getRigth()));
        }
    }

    public static float operacao(String op, float a, float b) {
        if(op.contentEquals("+"))
            return a+b;
        else if(op.contentEquals("-"))
            return a-b;
        else if(op.contentEquals("*"))
            return a*b;
        else
            return a/b;
    }


    public static void main(String[] args) {
        //String postfix="2 8 - 9 / 7 * 67 7 5 * + 8 7 * / -";
        String postfix = "30 4 2- 5* 7 3+/+";
        //String postfix = "10 2 -";
        ArrayStack<BTree<String>> s = new ArrayStack<BTree<String>>(100);
        String token;
        StringTokenizer st = new StringTokenizer(postfix," *+-/", true);
        BTree<String> a;
        BTree<String> b;

        while (st.hasMoreTokens()) {
            token = st.nextToken();
            if(!token.equals(" ")) {
                if(isNum(token)) {
                    s.push(new BTree<>(token));
                }
                else {
                    b = s.pop();
                    a = s.pop();

                    s.push(new BTree<>(token, a.raiz, b.raiz));
                }

            }
        }
        BTree<String> t = s.top();

        System.out.print("Em ordem");
        t.emOrdem();
        System.out.print("Pos ordem");
        t.posOrdem();
        System.out.print("Pre ordem");
        t.preOrdem();

        System.out.println(avalia(t));
    }
}