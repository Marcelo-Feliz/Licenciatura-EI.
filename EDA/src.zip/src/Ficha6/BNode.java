package Ficha6;
public class BNode <E>
{
    //variaveis
    E element;
    BNode <E> esq;
    BNode <E> drt;

    //construtor
    public BNode ()
    {
        this.element = null;
        this.esq = null;
        this.drt = null;
    }

    public BNode (E element)
    {
        this.element = element;
        this.esq = null;
        this.drt = null;
    }

    public BNode (E element, BNode <E> esq, BNode <E> drt)
    {
        this.element = element;
        this.esq = esq;
        this.drt = drt;
    }

    //metodos
    public BNode <E> getLeft()
    {
        return esq;
    }

    public BNode <E> getRigth()
    {
        return drt;
    }

    public E getElement()
    {
        return element;
    }

    public void setLeft(BNode <E> esq)
    {
        this.esq = esq;
    }

    public void setRigth(BNode <E> drt)
    {
        this.drt = drt;
    }

    public void setElement(E element)
    {
        this.element = element;
    }

}