package Ficha5LinkedList;

public class LinkedList<T> implements Iterable<T>, Lista<T>{

    SingleNode<T> header;
    SingleNode<T> tail;
    int size;

    public LinkedList(){
        header = tail = new SingleNode<>();
        size = 0;
    }
    public java.util.Iterator<T> iterator(){
        return new LinkedListIterator<T>(header.next);
    }
    public int size(){
        return size;
    }
    public boolean isEmpty(){
        return size==0;
    }
    public SingleNode<T> header(){
        return header;
    }
    public void add(int i, T x){
        SingleNode<T> prev = getNode(i-1);
        SingleNode<T> newNode = new SingleNode<T>(x,prev.getNext());
        prev.setNext(newNode);
        size++;
    }
    void add(SingleNode<T> prev, T x){
        SingleNode<T> newNode = new SingleNode<>(x,prev.getNext());
        prev.setNext(newNode);
        size++;
    }
    void remove(SingleNode<T> prev){
        prev.setNext(prev.getNext().getNext());
        size--;
    }
    public T remove(int ind){
        T returned = getNode(ind).element();
        getNode(ind -1).setNext(getNode(ind+1));
        size--;
        return returned;
    }
    public void add(T x){}
    public void clear(){}
    public void remove(T x){
        SingleNode<T> temporary = header().getNext();
        SingleNode<T> temporaryPrev = header();
        for(int i = 0; i<size; i++){
            if(temporary.element().equals(x)){
                remove(temporaryPrev);
                temporaryPrev = temporaryPrev.getNext();
                temporary = temporary.getNext();
                remove(x);
            }else{
                temporary = temporary.getNext();
                temporaryPrev = temporaryPrev.getNext();
            }
        }
    }
    public  String toString(){
        SingleNode<T> temporary = header().getNext();
        String s = "[";
        for (int i =0; i<size; i++){
            if(i < size-1){
                s = s + temporary.element() + ";";
                temporary = temporary.getNext();
            }else{
                s = s + temporary.element();
                temporary = temporary.getNext();
            }
        }
        s = s + "]";
        return s;
    }
    public void set(int indx, T x){
        getNode(indx).setElement(x);
    }
    public T get(int ind){
        return getNode(ind).element();
    }
    SingleNode<T> getNode(int i){
        int in = -1;
        SingleNode<T> s = header();
        while(in<i && s!=null){
            s = s.getNext();
            in++;
        }
        return s;
    }

    public static void main(String[] args) {
        LinkedList<Integer> l=new LinkedList<Integer>();
        System.out.println(l);
        l.add(0,1);
        System.out.println(l);
        l.add(1,2);
        l.add(0,5);
        l.add(2,7);
        l.add(4,9);
        l.add(5,100);
        System.out.println(l);
        System.out.println(l.size());
        l.add(l.size(),8);
        System.out.println(l);
        System.out.println(l.get(3));
        l.set(3,100);
        System.out.println(l);
        System.out.println(l.remove(2));
        l.add(5,100);
        System.out.println(l);
        l.remove(new Integer(100));
        System.out.println(l);
        java.util.Iterator<Integer> it=l.iterator();
        System.out.println(it.hasNext());
        System.out.println(it.next());
        l.remove(it.next());
        System.out.println(l);
        System.out.println(it.next());
    }

}
