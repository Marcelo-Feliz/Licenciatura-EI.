package Ficha5LinkedList;

public class SingleNode<T>{

    T info;                                                              //Guarda a informação do node
    SingleNode<T> next;                                                  //Refere-se ao seguinte node

    ///// Define o que está no nó, apagando, caso exista um seguinte /////

    public SingleNode(T x){
        this.info = x;
        this.next = null;
    }

    ///// Apaga totalmente o nó /////

    public SingleNode(){
        //this(null,null);
        this.info = null;
        this.next = null;
    }

    ///// Define o que está no nó e o seguinte /////

    public SingleNode(T x, SingleNode<T> n){
        this.info = x;
        this.next = n;
    }

    ///// Retorna a informação do nó caso este exista /////

    public T element(){
        if(info==null){
            System.out.println("Node not found");
            return null;
        }
        return this.info;

    }

    ///// Retorna caso exista o seguinte /////

    public SingleNode<T> getNext(){
        return next;
    }

    ///// Define a informação do nó como x /////

    public void setElement(T x){
        this.info = x;
    }

    ///// Define o seguninte como n /////

    public void setNext(SingleNode<T> n){
        this.next = n;
    }
}
