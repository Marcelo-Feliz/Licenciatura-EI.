package Ficha5LinkedList;

public interface Iterable<T> {
    java.util.Iterator<T> iterator();
}
