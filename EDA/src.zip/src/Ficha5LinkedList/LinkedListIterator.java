package Ficha5LinkedList;

public class  LinkedListIterator<T> implements java.util.Iterator<T> {

    SingleNode<T> atual;

    public LinkedListIterator(SingleNode<T> a) {
        atual = a;
    }

    public boolean hasNext() {
        return atual!=null;
    }

    public T next() {
        if(hasNext()){
            T obj = atual.info;
            atual=atual.next;
            return obj;
        }
        return null;
    }

    public void remove() {
    }
}