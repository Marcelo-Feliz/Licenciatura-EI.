package Ficha5LinkedList;

public interface Iterator<T> {
    boolean hasNext();
    T next();
    void remove();
}