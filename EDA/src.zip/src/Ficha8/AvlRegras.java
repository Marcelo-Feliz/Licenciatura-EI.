package AVL_Teste;
/*
public class NoAVL<E extends Comparable<? super E>> {
    E elemento;
    NoAVL<E> esq, dir, raiz;
    int height;

    NoAVL(E e){
        this(e, null, null);
    }

    NoAVL(E e, NoAVL<E> lt, NoAVL<E> rt){
        elemento = e;
        lt = esq;
        rt = dir;
        height = 0;
    }

    private int height(NoAVL<E> n){
        return n == null ? -1 : n.height;
    }

    public boolean isEmpty(){
        return raiz == null;
    }

    public void insert(E x){
        raiz = insert(x, raiz);
    }

    private NoAVL<E> insert(E x, NoAVL<E> n ){
        if(n == null)
            return new NoAVL<E>(x, null, null);

        if( (n.elemento).compareTo(x) < 0)
            n.esq = insert(x, n.esq);
        else if((n.elemento).compareTo(x) > 0)
            n.dir = insert(x, n.dir);
        else
            ;   //Duplicate; do nothing
        return balance(n);

    }

    private static final int ALLOWED_IMBALANCE = 1;

    private NoAVL<E> balance(NoAVL<E> n){
        if(n==null)
            return n;
        if(height(n.esq) - height(n.dir) > ALLOWED_IMBALANCE)
            if(height(n.esq.esq) >= height(n.esq.dir))
                n = rotateWithLeftChild(n);
            else
                n = doubleWithLeftChild(n);
        else
            if(height(n.dir) - height(n.esq) > ALLOWED_IMBALANCE)
                if(height(n.dir.dir) >= height(n.dir.esq))
                    n = rotateWithRightChild(n);
                else
                    n = doubleWithRightChild(n);

            n.height = Math.max(height(n.esq), height(n.dir) ) + 1;
            return n;
    }

    private NoAVL<E> rotateWithLeftChild(NoAVL<E> k2){
        NoAVL<E> k1 = k2.esq;
        k2.esq = k1.dir;
        k1.dir = k2;
        k2.height = Math.max(height(k2.esq), height(k2.dir)) + 1;
        k1.height = Math.max(height(k1.esq), k2.height) + 1;
        return k1;
    }

    private NoAVL<E> rotateWithRightChild(NoAVL<E> k2){
        NoAVL<E> k1 = k2.dir;
        k2.dir = k1.esq;
        k1.esq = k2;
        k2.height = Math.max(height(k2.dir), height(k2.esq)) + 1;
        k1.height = Math.max(height(k1.dir), k2.height) +1;
        return k1;
    }

    private NoAVL<E> doubleWithLeftChild(NoAVL<E> k3){
        k3.esq = rotateWithRightChild(k3.esq);
        return rotateWithLeftChild(k3);
    }

    private NoAVL<E> doubleWithRightChild(NoAVL<E> k3){
        k3.dir = rotateWithLeftChild(k3.dir);
        return rotateWithRightChild(k3);
    }

    public void remove(E x){
        raiz = remove(x, raiz);
    }

    private NoAVL<E> remove(E x, NoAVL<E> n){
        if(n == null)
            return n;

        int compareResult = x.compareTo(n.elemento);

        if(compareResult < 0)
            n.esq = remove(x, n.esq);
        else if(compareResult > 0)
            n.dir = remove(x, n.dir);
        else if(n.esq != null && n.dir != null){
            E min = findMin(n.dir);
            n.elemento = min;
            n.dir = remove(min, n.dir);
        }
        else
            n = (n.esq != null) ? n.esq : n.dir;
        return balance(n);
    }

    public E findMin() {
        if (isEmpty())
            return null;
        return findMin(raiz);
    }

    private E findMin(NoAVL<E> n) {
        if (n.esq == null)
            return n.elemento;
        else
            return findMin(n.esq);
    }



}

public E next(){ 
if( !hasNext() ) 
throw new java.util.NoSuchElementException( ); 
E to_return=atual.elem(); //salvaguardar a direita 
if (atual.dir()!=null){ choice_points.push(atual.dir());     } //atualizar a esquerda 
if(atual.esq()!=null){ atual=atual.esq();     } else{ if(!choice_points.empty()){ atual=choice_points.pop();         } else atual=null; // its over 
} 
return to_return; 
}
*/