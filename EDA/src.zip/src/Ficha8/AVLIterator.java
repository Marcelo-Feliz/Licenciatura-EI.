package Ficha8;


///////////IMCOMPLETO


import Ficha3.ArrayStack;
import Ficha5LinkedList.Iterator;

public class AVLIterator<E> implements Iterator{

    static class BNode<E> {

        E element;
        BNode<E> left;
        BNode<E> right;

        BNode(E e) {

            element = e;
            left = null;
            right = null;
        }

        BNode(E element, BNode<E> left, BNode<E> right) {

            this.element = element;
            this.left = left;
            this.right = right;
        }
    }

    BNode<E> atual;

    ArrayStack<BNode<E>> choice_points= new ArrayStack<BNode<E>>();

    public boolean hasNext(){
        return atual!=null;
    }

    public E next(){
        if( !hasNext() ) {
            throw new java.util.NoSuchElementException();
        }
        E resul=atual.element;
        if (atual.right!=null){
            choice_points.push(atual.right);
        }
        if(atual.left!=null){
            atual=atual.left;
        }else if(!choice_points.empty()){
            atual=choice_points.pop();
        }
        else{ atual=null; // its over
        }
        return resul;
    }
    public void remove(){
        throw new  UnsupportedOperationException();
    }
}
