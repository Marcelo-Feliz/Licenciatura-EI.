package Ficha8;
import Ficha7.ABP;

////////////IMCOMPLETO

public class AVLs <E extends Comparable<? super E>> implements ABP<E>, Iterable<E>{


    public java.util.Iterator<E> iterator(){
        return null;
    }

    BNode<E> raiz;

    public BNode<E> getRaiz(){
        return raiz;
    }

    static class BNode<E> {

        E element;
        BNode<E> left;
        BNode<E> right;

        BNode(E e) {

            element = e;
            left = null;
            right = null;
        }

        BNode(E element, BNode<E> left, BNode<E> right) {

            this.element = element;
            this.left = left;
            this.right = right;
        }
    }

    public boolean isEmpty() {
        return raiz == null;
    }
    public boolean contains(E x){
        return contains(x,raiz);
    }

    private boolean contains(E x, BNode<E> n){
        if (n==null) {
            return false;
        }
        else{
            if (n.element.compareTo(x)<0) {
                return contains(x, n.right);
            }
            else if (n.element.compareTo(x)>0) {
                return contains(x, n.left);
            }
            else{
                return true;
            }
        }
    }
    public E findMin(){
        if (isEmpty())
            return null;
        return findMin(raiz);
    }
    private E findMin(BNode<E> n){
        if (n.left==null)
            return  n.element;
        else
            return findMin(n.left);
    }
    public E findMax() {
        return null;
    }
    public void insert(E x) {
        raiz=insert(x,raiz);
    }
    private BNode<E> insert(E x, BNode<E> n){
        if (n==null)
            n=new BNode<E>(x,null,null);
        else if ((n.element).compareTo(x)>0)
            n.left = insert(x,n.left);
        else if((n.element).compareTo(x)<0)
            n.right = insert(x,n.right);
        return n;
    }
    public void remove(E x) {
        raiz = remove(x, raiz);
    }
    private BNode<E> remove(E x, BNode<E> n){
        if (n==null){
            return n;
        }
        if (n.element.compareTo(x)<0){
            n.right = (remove(x, n.right));
        }
        else if(n.element.compareTo(x)>0) {
            n.left = (remove(x, n.left));
        }
        else if (n.left!=null && n.right!=null){
            E min = findMin(n.right);
            n.element = (min);
            n.right = (remove(min,n.right));
        }
        else if (n.left==null) {
            n=n.right;
        }
        else{
            n=n.left;
        }
        return n;
    }
    public void printEmOrdem(){
        if(isEmpty())
            System.out.println("Empty tree");
        else
            printEmOrdem(raiz);
    }

    public void printPosOrdem(){
        if(isEmpty())
            System.out.println("Empty tree");
        else
            printPosOrdem(raiz);
    }

    public void printPreOrdem(){
        if(isEmpty())
            System.out.println("Empty tree");
        else
            printPreOrdem(raiz);
    }

    private void printEmOrdem(BNode<E> n) {
        if (n != null) {
            printEmOrdem(n.left);
            System.out.print(" " + n.element);
            printEmOrdem(n.right);
        }
    }

    private void printPosOrdem(BNode<E> n) {
        if (n != null) {
            printPosOrdem(n.left);
            printPosOrdem(n.right);
            System.out.print(" " + n.element);
        }
    }

    private void printPreOrdem(BNode<E> n) {
        if (n != null) {
            System.out.print(" " + n.element);
            printPreOrdem(n.left);
            printPreOrdem(n.right);
        }
    }
}
