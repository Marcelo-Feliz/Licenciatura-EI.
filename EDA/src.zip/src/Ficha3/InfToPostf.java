package Ficha3;

public class InfToPostf{
    int maxSize;

    ArrayStack<Integer> values = new ArrayStack<>(maxSize);

    public InfToPostf(){
        maxSize=100;
    }
    public InfToPostf(int size){
        maxSize=size;
    }

    public boolean isNumeric(char s){
        if(s=='1'||s=='2'||s=='3'||s=='4'||s=='5'||s=='6'||s=='7'||s=='8'||s=='0'||s=='9'){
            return true;
        }
        return false;
    }

    public boolean isOperator(char s){
        if(s=='/'||s=='*'||s=='+'||s=='-'){
            return true;
        }
        return false;
    }

    public void readInf(String eq){
        String s="";
        int value;
        for(int i = 0; i<eq.length(); i++){
            if((isNumeric(eq.charAt(i)))){
                s = s + eq.charAt(i);
                value = Integer.parseInt(s);
            }else if(eq.charAt(i)=='('){
                if(isOperator(eq.charAt(i+1))){
                    System.out.println("Expressão erradda");
                    System.exit(1);
                }
                s="";
            }else if(eq.charAt(i)==' '){
                if(isNumeric(eq.charAt(i-1)) && isNumeric(eq.charAt(i+1))){
                    System.out.println("Expressão erradda");
                    System.exit(1);
                }
                s="";
            }else if(isOperator(eq.charAt(i))){
                if(isOperator(eq.charAt(i-1)) || isOperator(eq.charAt(i+1))){
                    System.out.println("Expressão erradda");
                    System.exit(1);
                }
                s="";
            }else if(eq.charAt(i)==')'){
                if(isOperator(eq.charAt(i-1))){
                    System.out.println("Expressão erradda");
                    System.exit(1);
                }
                s="";
            }

        }
    }

}
//incompleto
