package Ficha3;
import java.util.Scanner;
public class TesteParentesis{

    public static ArrayStack<Character> chars = new ArrayStack<>(100);

    public static void test(String equation){
        for(int i = 0; i<equation.length(); i++){
            changeStack(equation.charAt(i));
        }
    }

    public static boolean isOpenParen(char s){
        if(s=='('){
            return true;
        }else {
            return false;
        }
    }
    public static boolean isCloseParen(char s){
        if(s==')'){
            return true;
        }else{
            return false;
        }
    }
    public static void changeStack(char s) {
        if(chars.empty() && isCloseParen(s)){
            System.out.println("Número de parêntesis está incorreto");
            System.exit(1);
        }
        else if(isCloseParen(s)){
            chars.pop();
        }else if(isOpenParen(s)) {
            chars.push(s);
        }
    }

    public static boolean marrie(String equation){
        test(equation);
        if(chars.empty()){
            return true;
        }else
        return false;

    }

    public static void main(String[] args){

        System.out.println("Digite a expressão;");
        Scanner s = new Scanner(System.in);
        String exp = s.nextLine();
        if(marrie(exp)){
            System.out.println("Número de parêntesis está correto");
        }else{
            System.out.println("Número de parêntesis está incorreto");
        }
    }
}
