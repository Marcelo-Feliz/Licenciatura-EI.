package Ficha3;

public class ArrayStack<E> implements Stack<E>{

    private E[] stack;
    int top;
    int size;

    public ArrayStack(){
        size = 20;
        stack = (E[]) new Object[size];
        top = 0;
    }

    public ArrayStack(int size){
        stack = (E[]) new Object[size];
        this.size = size;
    }

    public void push(E o) {
        stack[top] = o;
        top++;
    }

    public E top() {
        if (empty()){
            return null;
        }
        return stack[top-1];
    }

    public E pop() {
        if(empty()){
            return null;
        }
        E res = stack[top-1];
        top = top - 1;
        return res;
    }

    public int size() {
        return top;
    }

    public boolean empty() {
        return top == 0;
    }

    public String toString() {
        String res= "[ ";
        for (int i = 0; i < top; i++){
            res += (i<top-1)? stack[i]+" ; ":stack[i];      //se i for menor a top-1 executa o q está antes do ":" caso contrario executa o q esta depois
            }
        return res + " ]";
    }

    public static void main(String[] args){
        ArrayStack<Integer> ints = new ArrayStack<>();
        ArrayStack<String> strns = new ArrayStack<>(3);
        ints.push(0);
        ints.push(27);
        ints.push(9);
        System.out.println(ints);
        System.out.println(ints.pop());
        System.out.println(ints.top());

    }

}
