package TrabalhoFinalEDA1;

import java.io.BufferedReader;                            /// Não é implementação nossa
import java.io.File;                                      /// mas achou-se necessario
import java.io.FileReader;                                /// a utilização destes imports
import java.util.Scanner;                                 /// para a leitura dos ficheiros
import java.io.FileNotFoundException;                     /// e "correção" de excecões

public class BoggleSolution<T>{

    ///// Método para diminuir o tamanho da palavra, para calcular o prefixo com 1 caracter a menos (o último) /////

    public static String dimin(String palavra){
        String atual = "";
        for(int i = 0; i < palavra.length()-1; i++ ){
            atual = atual + palavra.charAt(i);
        }
        return atual;
    }

    public static class palPosis{
        String palavra;
        LinkedList<posicao> posis = new LinkedList();
        String finale;

        public palPosis(String palavra , LinkedList posis){
            this.palavra = palavra;
            this.posis = posis;
            this.finale = palavra + " " + posis.toString();
        }
    }

    ///// Classe para criar a posicao /////

    public static class posicao{
        public char letra;
        int i;
        int j;
        boolean foiVisto;

        public posicao(char x, int i , int j) {
            letra = x;
            this.i = i;
            this.j = j;
            foiVisto = false;
        }

        public posicao(char x, int i , int j, boolean v) {
            letra=x;
            this.i = i;
            this.j = j;
            foiVisto = v;
        }
        public String toString(){
            return "("+letra+":("+i+","+j+"))";
        }
        public boolean equals(){
            return false;
        }
    }

    ///// Método (Recursivo) para testar se as palavras lidas no bogle existem na hashtable e as printar com as respetivas coordenadas /////
    ///// Sendo a HashTable dicionario a table com as palavras todas, a prefixos com todos os prefixos, a matrix é a matriz do bogle,  /////
    ///// os inteiros i e j sao as coordenadas da posição (inicial se for no primeiro caso, antes da recursividade), count é o numero  /////
    ///// de vezes que a função é recursiva pra uma direção, ou seja, o tamanho da palavra a ser procurada, palavra a propria palavra  /////
    ///// que tem de começar vazia e vai aumentando à medida que a função for chamada, e por fim, a linkedlist guardarPosi serve para  /////
    ///// guardar a palavra encontrada, como cada posição tem um valor para char, 2 ints e um boolean, é possível guardar a palavra    /////
    ///// onde cada letra vai ter as respetivas coordenadas, sendo assim possível printar as palavras finais como pedido no enunciado  /////

    public static void finalExecucao(HashTable dicionario, HashTable prefixos, posicao[][] matrix, int i, int j, int count, String palavra, LinkedList guardarPosi, LinkedList palavras) {
        count++;
        palavra = palavra + matrix[i][j].letra;

        if(dicionario.procurar(palavra) != null && dicionario.procurar(palavra).equals(palavra)){       /// Caso a posicao do dicionario com o indice palavra.hashCode esteja em uso verificar se a palavra lá existente é igual à palavra que é encontrada
            palPosis palPosisAtual = new palPosis(palavra, guardarPosi);
            palavras.add(palPosisAtual);
        }
        if(prefixos.procurar(palavra) == null || !prefixos.procurar(palavra).equals(palavra) && palavra.length()>=2){
            return;
        }

        if(j < 3 && !matrix[i][j+1].foiVisto){
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i][j+1]);
            finalExecucao(dicionario,prefixos,matrix,i,j+1,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i][j+1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (j < 3 && i > 0  && !matrix[i-1][j+1].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i-1][j+1]);
            finalExecucao(dicionario,prefixos,matrix,i-1,j+1,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i-1][j+1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (i > 0 && !matrix[i-1][j].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i-1][j]);
            finalExecucao(dicionario,prefixos,matrix,i-1,j,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i-1][j]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (j > 0 && i > 0 && !matrix[i-1][j-1].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i-1][j-1]);
            finalExecucao(dicionario,prefixos,matrix,i-1,j-1,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i-1][j-1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (j > 0 && !matrix[i][j-1].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i][j-1]);
            finalExecucao(dicionario,prefixos,matrix,i,j-1,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i][j-1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (j > 0 && i < 3 && !matrix[i+1][j-1].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i+1][j-1]);
            finalExecucao(dicionario,prefixos,matrix,i+1,j-1,count++, palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i+1][j-1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (i < 3 && !matrix[i+1][j].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i+1][j]);
            finalExecucao(dicionario,prefixos,matrix,i+1,j,count++,palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i+1][j]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if (i < 3 && j < 3 && !matrix[i+1][j+1].foiVisto) {
            matrix[i][j].foiVisto = true;
            guardarPosi.add(matrix[i+1][j+1]);
            finalExecucao(dicionario,prefixos,matrix,i+1,j+1,count++,palavra,guardarPosi,palavras);
            guardarPosi.remove(matrix[i+1][j+1]);
            count--;
            matrix[i][j].foiVisto = false;
        }
        if(count == 1){
            guardarPosi.remove(0);                                                              //Caso seja a primeira letra precisa ser removida da linkedlist porque nao é inserida na função *
        }
    }
    public static class HashTableTeste<T> extends HashTable{}                                       //É necessario criar essa classe, porque como a Hashtable é abstrata não é possivel criar objetos dela**

    public static void main(String[] args)throws FileNotFoundException{

        HashTable<String> tableDicionario = new HashTableTeste<String>();                                //**
        HashTable<String> prefixos = new HashTableTeste<String>();                                       //**
        tableDicionario.tornaVazia();
        prefixos.tornaVazia();
        String palavra = "";

        /// Ficheiro com a respetiva localização ("/home/*perfil*/Desktop/dicionario" , que varia dependendo do computador, o sistema operativo e do local da memoria onde esta o ficheiro) ///

        File dicionario = new File("/home/shady/Desktop/Segundo Ano - exercicios/Trabalho EDA1 FINAL/dicionario");
        File bogle = new File("/home/shady/Desktop/Segundo Ano - exercicios/Trabalho EDA1 FINAL/Boggle5");

        /// Scanner para ler o ficheiro (dicionario) ///

        Scanner sc = new Scanner(new BufferedReader(new FileReader(dicionario)));

        /// Ciclo para ler as palavras do dicionario e as colocar na table com os respetivos prefixos noutra table diferente ///

        while(sc.hasNextLine()) {
            palavra = sc.nextLine();
            tableDicionario.insere(palavra);
            String palav = palavra;
            for(int i = 0 ; i < palavra.length() -1 ; i++){
                palav = dimin(palav);
                prefixos.insere(palav);
            }
        }

        /// Scanner para ler o ficheiro do bogle ///

        sc = new Scanner(new BufferedReader(new FileReader(bogle)));
        String bogles = sc.nextLine();
        int atual = 0;
        posicao[][] matriz = new posicao[4][4];

        /// Ciclos para criar a matriz do bogle ///

        for(int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                matriz[i][j] = new posicao(bogles.charAt(atual),i,j,false);
                atual++;
            }
        }
        LinkedList<posicao> guardarPosi = new LinkedList();
        LinkedList<palPosis> palavras = new LinkedList<>();

        for(int i = 0; i < 16; i=i+4){
            for (int j = 0; j < 4; j++){
                guardarPosi.add(new posicao(bogles.charAt(i+j),i/4,j));                                                //* foi aqui onde a inserção da letra inicial foi colocada na linkedlist
                finalExecucao(tableDicionario,prefixos,matriz,i/4,j,0,"",guardarPosi,palavras);
            }
        }
        System.out.println("Encontradas " + palavras.size() + " soluções\n");
        for(int i = 0; i < palavras.size(); i++){
            palPosis algo = palavras.get(i);
            System.out.println(algo.finale);
        }
    }
}
