package TrabalhoFinalEDA1;

////// INTERFACE PARA A LINKEDLIST /////

public interface LinkedListINter<T>{
    void add(T x);
    void add(int i, T x);
    void set(int i, T x);
    T remove(int i);
    void remove(T x);
    void clear();
    T get(int i);
    int size();
}
