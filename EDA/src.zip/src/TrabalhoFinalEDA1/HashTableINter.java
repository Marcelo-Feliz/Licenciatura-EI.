package TrabalhoFinalEDA1;

public interface HashTableINter<T> {
    public int ocupados();
    public int capacity();
    public float fatorCarga();
    public int procPos(T x);
    public void alocarTabela(int n);
    public void tornaVazia();
    public T procurar(T x);
    public void remove(T x);
    public void insere(T x);
    public void rehash();
    public void print();
}
