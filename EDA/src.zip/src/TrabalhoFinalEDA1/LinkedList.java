package TrabalhoFinalEDA1;

///// Implementação LinkedList /////

public class LinkedList<T> implements LinkedListINter<T> {

    SingleNode<T> header;                                  // Primeiro nó da lista
    SingleNode<T> tail;                                    // Ultimo nó da lista
    int tam;                                               // Tamanho da lista

    ///// Construtor que define //////

    public LinkedList(){
        header = tail = new SingleNode<>();
        tam = 0;
    }

    ///// Retorna o tamanho atual da linkedlist /////

    public int size(){
        return tam;
    }

    ///// Retorna trua se a lista estiver vazia, false caso contrario /////

    public boolean isEmpty(){
        return tam ==0;
    }

    ///// Retorna o nó inicial /////

    public SingleNode<T> header(){
        return header;
    }

    ///// Adiciona um objeto x na posição i da lista /////

    public void add(int i, T x){
            SingleNode<T> prev = getNode(i - 1);
            SingleNode<T> newNode = new SingleNode<T>(x, prev.getNext());
            prev.setNext(newNode);
            tam++;
    }

    ///// Adiciona um objeto x na posição a seguir ao nó prev /////

    void add(SingleNode<T> prev, T x){
        SingleNode<T> newNode = new SingleNode<>(x,prev.getNext());
        prev.setNext(newNode);
        tam++;
    }

    ///// Define o seguinte do nó prev como o seguinte do seu seguinte, ou seja, o seguinte ao nó prev deixa de ser acessível na lista (é removido) /////

    void remove(SingleNode<T> prev){
        prev.setNext(prev.getNext().getNext());
        tam--;
    }

    ///// Remove o nó de indice index e retorna-o /////

    public T remove(int index){
        T returned = getNode(index).element();
        getNode(index -1).setNext(getNode(index+1));
        tam--;
        return returned;
    }

    ///// Adiciona no final da lista o objeto x /////

    public void add(T x){
        add( size( ), x );
    }

    ///// Apaga todos os nós da lista /////

    public void clear(){
        for(int i = 0; i < tam; i++){
            remove(i);
        }
        tam = 0;
    }

    ///// Remove o nó que tem como objeto x /////

    public void remove(T x){
        SingleNode<T> temporaria = header().getNext();
        SingleNode<T> anterior = header();
        for(int i = 0; i< tam; i++){
            if(temporaria.element().equals(x)){
                remove(anterior);
                anterior = anterior.getNext();
                temporaria = temporaria.getNext();
                remove(x);
            }else{
                temporaria = temporaria.getNext();
                anterior = anterior.getNext();
            }
        }
    }

    ///// Retorna a lista em forma de string: o elemento do primeiro nó -> elemento do segundo -> ...... -> elemento do ultimo nó /////

    public  String toString(){
        SingleNode<T> temporaria = header().getNext();
        String s = "";
        for (int i = 0; i< tam; i++){
            if(i < tam -1){
                s = s + temporaria.element() + "->";
                temporaria = temporaria.getNext();
            }else{
                s = s + temporaria.element();
                temporaria = temporaria.getNext();
            }
        }
        s+="";
        return s;
    }

    ///// Define o elemento do nó de indice indx como x /////

    public void set(int indx, T x){
        getNode(indx).setElement(x);
    }

    ///// Retorna o elemento do nó de indice ind /////

    public T get(int ind){
        return getNode(ind).element();
    }

    ///// Retorna o nó de indice index /////

    SingleNode<T> getNode(int index){
        SingleNode<T> no = header();
        for(int i = -1; i<index && no!=null; i++){
            no = no.getNext();
        }
        return no;
    }
}
